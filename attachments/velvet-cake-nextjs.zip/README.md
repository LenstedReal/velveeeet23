# VelvetAI — Next.js (App Router)
Python/requirements.txt yok; Vercel’e olduğu gibi deploy edilir.
Kurulum: `cp .env.example .env.local` → doldur → `npm i && npm run dev`.
Aynı Postgres JSONB şemasını ve aynı JWT/bcrypt formatını kullanır: mevcut kullanıcı ve token’lar geçerli kalır.
DATABASE_URL yoksa uygulama çökmez, DB’li uçlar 503 döner. CORS gerekmez (aynı origin); istemcide base URL = "" (`/api/...`).

Taşınan uçlar: GET /api, POST /api/auth/register, POST /api/auth/login, GET /api/auth/me, GET /api/characters, POST /api/chat/stream.
Taşınacaklar: PATCH auth/me, Discord OAuth, characters CRUD, conversations/messages, images, media, voice/tts (edge-tts Python’a özgü), scenarios, stories, live, roulette, seed_data.py -> lib/seed.js.
Frontend: src/components/* dosyalarına "use client" ekleyip app/ altına taşı; api.js’te BACKEND_URL yerine "".
