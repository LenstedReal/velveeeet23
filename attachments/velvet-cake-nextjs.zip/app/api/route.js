export const GET = () => Response.json({ app: 'VelvetAI', status: 'ok' });
