import { handle, userIdFrom } from "@/lib/api";
import { query } from "@/lib/db";

export const GET = handle(async (req) => {
  const uid = await userIdFrom(req, false);
  const q = new URL(req.url).searchParams;
  const where = []; const args = [];
  const owner = q.get("owner");
  if (owner === "me" && uid) { args.push(uid); where.push(`data->>\x27owner_id\x27 = $${args.length}`); }
  else if (owner !== "official" && uid) { args.push(uid); where.push(`(data->>\x27owner_id\x27 IS NULL OR data->>\x27owner_id\x27 = $${args.length})`); }
  else where.push("data->>\x27owner_id\x27 IS NULL");
  for (const k of ["gender", "style"]) if (q.get(k)) { args.push(q.get(k)); where.push(`data->>\x27${k}\x27 = $${args.length}`); }
  if (q.get("is_new") === "true") where.push("(data->>\x27is_new\x27)::boolean IS TRUE");
  if (q.get("online") === "true") where.push("data->>\x27status\x27 = \x27online\x27");
  const rows = await query(`SELECT data FROM characters WHERE ${where.join(" AND ")} ORDER BY pk LIMIT 500`, args);
  return Response.json(rows.map((r) => r.data));
});
