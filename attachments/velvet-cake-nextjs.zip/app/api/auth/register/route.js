import { randomUUID } from "crypto";
import { handle, HttpError, hashPassword, createToken, publicUser } from "@/lib/api";
import { findOne, insert } from "@/lib/db";

export const POST = handle(async (req) => {
  const b = await req.json();
  const email = String(b.email || "").toLowerCase().trim();
  if (!/^\S+@\S+\.\S+$/.test(email) || String(b.password || "").length < 6) throw new HttpError(422, "Invalid email or password");
  if (await findOne("users", { email })) throw new HttpError(400, "Email already registered");
  const name = (b.name || email.split("@")[0]).slice(0, 40);
  const user = {
    id: randomUUID(), email, name, password_hash: await hashPassword(b.password),
    avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=ec4899&color=fff`,
    created_at: new Date().toISOString(),
  };
  await insert("users", user);
  return Response.json({ access_token: await createToken(user.id), token_type: "bearer", user: publicUser(user) });
});
