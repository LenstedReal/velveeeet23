import { handle, HttpError, userIdFrom, publicUser } from "@/lib/api";
import { findOne } from "@/lib/db";

export const GET = handle(async (req) => {
  const u = await findOne("users", { id: await userIdFrom(req) });
  if (!u) throw new HttpError(404, "User not found");
  return Response.json(publicUser(u));
});
