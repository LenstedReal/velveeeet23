import { handle, HttpError, verifyPassword, createToken, publicUser } from "@/lib/api";
import { findOne } from "@/lib/db";

export const POST = handle(async (req) => {
  const b = await req.json();
  const u = await findOne("users", { email: String(b.email || "").toLowerCase().trim() });
  if (!u || !(await verifyPassword(b.password || "", u.password_hash))) throw new HttpError(401, "Invalid email or password");
  return Response.json({ access_token: await createToken(u.id), token_type: "bearer", user: publicUser(u) });
});
