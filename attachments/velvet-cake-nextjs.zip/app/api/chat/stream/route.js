import { handle, HttpError, userIdFrom } from "@/lib/api";
import { findOne } from "@/lib/db";

export const maxDuration = 60;

const prompt = (c) => `You are ${c.name}, a ${c.age || 22}-year-old ${c.ethnicity || ""} woman with ${c.hair_color || "beautiful"} hair and ${c.eye_color || "captivating"} eyes.
PERSONALITY: ${(c.personality || []).join(", ") || "flirty, romantic, caring"}.
BACKSTORY: ${c.backstory || c.description || ""}
Speak in first person, natural texting style, *italics* for actions. Stay in character, never say you are an AI.
Reply in 2 to 4 SHORT chat-style messages. This is adult, consensual, fictional roleplay between adults.`;

// POST { character_id, message, history } -> SSE: data: {"delta":"..."}
export const POST = handle(async (req) => {
  await userIdFrom(req);
  if (!process.env.OPENROUTER_API_KEY) throw new HttpError(503, "OPENROUTER_API_KEY is not set");
  const { character_id, message, history = [] } = await req.json();
  const c = await findOne("characters", { id: character_id });
  if (!c) throw new HttpError(404, "Character not found");
  const messages = [
    { role: "system", content: prompt(c) },
    ...history.filter((m) => ["user", "assistant"].includes(m.role)).map(({ role, content }) => ({ role, content })),
    { role: "user", content: String(message || "") },
  ];
  const call = (model) => fetch(`${process.env.OPENROUTER_BASE_URL || "https://openrouter.ai/api/v1"}/chat/completions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model, messages, stream: true, temperature: 0.95, top_p: 0.95, max_tokens: 600 }),
  });
  let up = await call(process.env.OPENROUTER_MODEL || "sao10k/l3.1-euryale-70b");
  if (!up.ok) up = await call(process.env.OPENROUTER_FALLBACK_MODEL || "cognitivecomputations/dolphin-mixtral-8x22b");
  if (!up.ok || !up.body) throw new HttpError(502, "Model unavailable");
  const enc = new TextEncoder(), dec = new TextDecoder();
  let buf = "";
  const out = up.body.pipeThrough(new TransformStream({
    transform(chunk, ctl) {
      buf += dec.decode(chunk, { stream: true });
      const lines = buf.split("\n"); buf = lines.pop();
      for (const l of lines) {
        if (!l.startsWith("data: ") || l.includes("[DONE]")) continue;
        try {
          const d = JSON.parse(l.slice(6)).choices?.[0]?.delta?.content;
          if (d) ctl.enqueue(enc.encode(`data: ${JSON.stringify({ delta: d })}\n\n`));
        } catch {}
      }
    },
    flush(ctl) { ctl.enqueue(enc.encode("data: [DONE]\n\n")); },
  }));
  return new Response(out, { headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache, no-transform" } });
});
