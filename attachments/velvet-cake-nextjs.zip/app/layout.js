export const metadata = { title: "VelvetAI" };
export default function RootLayout({ children }) {
  return (<html lang="tr"><body style={{ margin: 0, background: "#0b0b10", color: "#fff", fontFamily: "system-ui" }}>{children}</body></html>);
}
