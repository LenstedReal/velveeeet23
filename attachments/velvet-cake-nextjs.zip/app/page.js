"use client";
import { useEffect, useState } from "react";

export default function Home() {
  const [chars, setChars] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    fetch("/api/characters").then(async (r) => { const d = await r.json(); if (!r.ok) throw new Error(d.detail); setChars(d); }).catch((e) => setErr(e.message));
  }, []);
  return (
    <main style={{ padding: 16 }}>
      <h1>VelvetAI</h1>
      {err && <p style={{ color: "#f87171" }}>{err}</p>}
      {!chars && !err && <p>Yükleniyor…</p>}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(150px,1fr))", gap: 12 }}>
        {chars?.map((c) => (<div key={c.id}><img src={c.image || c.avatar} alt={c.name} style={{ width: "100%", borderRadius: 12 }} /><b>{c.name}</b></div>))}
      </div>
    </main>
  );
}
