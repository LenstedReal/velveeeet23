# Velvet-cake — Claude Fix Plan

## Proje
GitHub: LenstedReal/Velvet-cake

## Ana hedef
Mevcut JavaScript/React mimarisini bozmadan projeyi çalışır hale getir.
Geniş çaplı rewrite, framework değişimi veya gereksiz dependency upgrade yapma.

## Şu ana kadar yapılan düzeltmeler

### 1. Backend environment loading
backend/server.py içinde .env yolu düzeltildi.

Eski yapı:
Path(__file__).parent

Yeni yapı:
Path(__file__).resolve().parent.parent

Böylece root:
~/Velvet-cake/.env
doğru şekilde yükleniyor.

### 2. JWT environment handling
JWT_SECRET doğrudan os.environ["JWT_SECRET"] ile okunması nedeniyle environment eksikliğinde import sırasında çökme problemi incelendi.

JWT/JWT_SECRET değerleri .env üzerinden sağlanıyor.

### 3. OpenRouter environment handling
OPENROUTER_API_KEY için environment erişiminin import aşamasında gereksiz şekilde sert davranmaması yönündeki fix referansı mevcut.

### 4. DATABASE_URL import problemi
server.py içinde:

db = Database(os.environ["DATABASE_URL"])

yerine:

db = Database(os.environ.get("DATABASE_URL", ""))

kullanıldı.

### 5. DATABASE_URL olmadan local backend'in başlaması
PostgreSQL henüz kurulmadığı için startup sırasında local PostgreSQL'e bağlanıp:

ConnectionRefusedError: 127.0.0.1:5432

veriyordu.

Startup şu mantığa getirildi:

DATABASE_URL yoksa:
- backend çökmesin
- warning versin
- database olmadan ayağa kalksın

DATABASE_URL varsa:
- database.connect()
- seed_characters()
- upgrade_character_images()

çalışmaya devam etsin.

### 6. Mevcut test
Uvicorn artık startup aşamasında çalışıyor.

Beklenen log:

DATABASE_URL is not set — starting without database

ardından:

Application startup complete.

## ÖNEMLİ
Database henüz mevcut değil.

Bu nedenle DATABASE_URL olmaması şu an bilinçli bir durumdur.
Ancak database kullanan endpointlerin database yokken ne yaptığı ayrıca incelenmelidir.

## Sonraki düzeltme sırası

### P0 — Frontend build
Şu hata çözülmeli:

Cannot find module 'ajv/dist/compile/codegen'

Önce:

npm ls ajv ajv-keywords schema-utils

ve package.json / package-lock.json incelenmeli.

React/CRA mimarisini değiştirmeden dependency uyumsuzluğu çözülmeli.

`npm audit fix --force` KULLANILMAMALI.

### P0 — Backend dependency consistency
backend/requirements.txt ile gerçekten kurulu paket sürümleri karşılaştırılmalı.

Özellikle:
- FastAPI
- Starlette
- uvicorn
- sse-starlette
- httpx
- python-jose
- PyJWT
- asyncpg
- passlib
- edge-tts

kontrol edilmeli.

Gereksiz major upgrade yapılmamalı.

### P0 — Database davranışı
Database henüz yok.

DB kullanan endpointler tespit edilmeli.
Database yokken:
- backend process'i çökmemeli
- mümkünse anlaşılır 503/uygun hata dönmeli
- import/startup çalışmaya devam etmeli

Database sistemi tamamen silinmemeli.

### P1 — Frontend ↔ Backend bağlantısı
REACT_APP_BACKEND_URL kontrol edilmeli.

Trailing slash kaynaklı:
`//api/...`

oluşumu engellenmeli.

Frontend API çağrıları tek tek test edilmeli.

### P1 — Vercel
vercel.json incelenmeli.

Özellikle:

api/index.py

ve:

backend/**

dosyalarının serverless function içine dahil edilmesi doğrulanmalı.

### P1 — CORS
CORS production frontend URL'i ile test edilmeli.

Wildcard + credentials kombinasyonu körlemesine kullanılmamalı.

### P1 — Auth
Login/register/JWT/Discord OAuth akışları ayrı ayrı test edilmeli.

JWT_SECRET, Discord secret veya OpenRouter key source code içine yazılmamalı.

### P1 — API endpoint testi
Öncelikle:
- /api/
- /api/status
- auth endpointleri
- character endpointleri
- chat endpointleri
- conversation/message endpointleri

test edilmeli.

Database gerektiren endpointler ayrıca işaretlenmeli.

### P2 — UI/runtime hataları
Frontend build geçtikten sonra browser runtime hataları incelenmeli.

Console hataları:
- undefined imports
- route problemleri
- API URL problemleri
- React runtime errors
- authentication state problemleri

tek tek çözülmeli.

### P2 — Production test
Local:
frontend build
backend startup
API smoke test

sonrasında Vercel deployment test edilmeli.

## KATI KURALLAR

1. Mevcut JavaScript mimarisini koru.
2. Gereksiz React/CRA/framework migration yapma.
3. Çalışan özellikleri yeniden yazma.
4. Önce mevcut hatayı reproduce et.
5. Sonra minimum gerekli değişikliği yap.
6. Her fix'ten sonra test et.
7. Birden fazla problemi tek değişiklik altında gizleme.
8. Database henüz olmadığı için database eksikliğini proje kodunun tamamen bozuk olduğu şeklinde yorumlama.
9. Secrets hiçbir zaman source code'a yazılmamalı.
10. `npm audit fix --force` kullanma.
11. Her değişiklikten sonra `git diff` kontrol et.
12. Çalışan mevcut özellikleri koru.

## Şu an bilinen frontend blocker

npm install başarılı oldu.

Ancak:

npm run build

şu hatayla duruyor:

Cannot find module 'ajv/dist/compile/codegen'

Bundan sonraki ilk iş AJV dependency tree'sini incelemek.

Komut:

npm ls ajv ajv-keywords schema-utils

Sonuca göre minimum dependency düzeltmesi uygulanmalı.
